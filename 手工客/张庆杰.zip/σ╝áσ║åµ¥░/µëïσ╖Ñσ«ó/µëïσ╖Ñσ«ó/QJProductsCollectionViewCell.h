//
//  QJProductsCollectionViewCell.h
//  手工客
//
//  Created by 张庆杰 on 15/7/16.
//  Copyright (c) 2015年 张庆杰. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "QJMainModel.h"

@interface QJProductsCollectionViewCell : UICollectionViewCell

@property (nonatomic, strong) QJProducts *products;

@end
